# LinenLady Admin — update bundle

Drop each file into the matching path under your project. The folder layout in
this zip mirrors `src/`, so you can also unzip at the repo root and overwrite.

| File | Path | What changed |
|------|------|--------------|
| `InventoryContext.tsx` | `src/context/InventoryContext.tsx` | Sticky updates (#1) |
| `Drafts.tsx` | `src/components/admin/Drafts.tsx` | Prev/next nav (#2) + sticky wiring (#1) |
| `ItemDetailsCard.tsx` | `src/components/admin/ItemDetailsCard.tsx` | Square-style inline editing (#4) + sticky |
| `page.tsx` | `src/app/admin/page.tsx` | Centered landing screen (#3) |

No other files need to change. No edits to `@/types/inventory` are required — the
new context methods are declared via an extended interface inside
`InventoryContext.tsx`.

---

## 1. Stickier front end, refresh reconciles with the API

`InventoryContext` gained three optimistic mutators:

- `applyItemPatch(id, patch)` — merges fields into the matching list row.
- `removeItem(id)` — drops a row (after delete) and fixes the counts/total.
- `setThumbnail(id, url)` — updates a row's cached thumbnail.

Each one updates the shared list state immediately **and** calls
`invalidateCache()`, so:

- Edits made on the item screen show in the inventory list with no refresh.
- The next network fetch (or a full page reload) pulls fresh data from the API,
  which stays the source of truth.

`Drafts.tsx` now calls these after every successful mutation: PATCH (price, name,
description, quantity, publish/unpublish, featured), delete, set-primary,
replace, add photos, and delete photo (thumbnail follows the primary image).

Counts (`all` / `drafts` / `published`) are adjusted optimistically based on the
`isActive` / `isDraft` transition, so the filter badges stay correct between
refreshes.

## 2. Prev / next navigation on the item screen

A top bar on the item screen now has a **Inventory** back button and `‹` / `›`
buttons that walk the loaded inventory list. They:

- Move within the current page, and cross page boundaries automatically (loading
  the next/previous page, then landing on the correct edge row).
- Show position as `#<row> of <total>`, matching the list numbering.
- Respond to the Left/Right arrow keys (ignored while typing in a field).
- Disable at the ends, or if the current item isn't in the loaded list (e.g. a
  deep link before the list has loaded).

## 3. Centered landing screen

The admin home no longer renders as a short box floating near the top. It now
fills the viewport height (`min-h-[calc(100dvh-7rem)]`), vertically centers its
content, and is wrapped as a rounded panel so it reads as a deliberate hero
rather than a flush block. Card grid is explicitly centered.

## 4. Square-style item editing

`ItemDetailsCard` is now an inline editor instead of read-only text:

- **Name**, **Price** (`$` prefix, numeric), and **Description** are editable
  fields right on the card.
- The quantity stepper stays as-is (Square-like inline stock control).
- A single **Save changes** button commits name/price/description; fields also
  auto-save on blur. A "Saved" tick confirms success.
- Featured / Publish / Delete are unchanged.
- The AI panel and Similar Items panel still sit below and stay in sync — all
  edits flow through the same `onItemUpdated` path, so there's one source of
  truth for the item.

> Note: the photo-first intake flow (AI vision drafting) was intentionally left
> alone, since that's your deliberate architecture. The Square-like change is in
> the edit/detail screen where it adds the most value without removing the AI
> drafting step.
